import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, Maximize, Calendar, Home, ChevronRight, Building2 } from 'lucide-react';
import Navbar from '@/sections/Navbar';
import Footer from '@/sections/Footer';
import { parks } from '@/data';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const regions = ['全部地区', '上海市', '北京市', '深圳市', '杭州市', '广州市', '成都市'];
const areas = ['全部面积', '3万以下', '3-5万', '5-8万', '8万以上'];
const rentFreePeriods = ['全部年限', '3个月', '6个月', '12个月', '12个月以上'];
const facilitiesList = ['会议室', '咖啡厅', '健身房', '停车场', '餐厅', '宿舍', '实验室'];

export default function Park() {
  const [selectedRegion, setSelectedRegion] = useState('全部地区');
  const [selectedArea, setSelectedArea] = useState('全部面积');
  const [selectedPeriod, setSelectedPeriod] = useState('全部年限');
  const [selectedFacilities, setSelectedFacilities] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation<HTMLDivElement>();
  const { ref: filtersRef, isVisible: filtersVisible } = useScrollAnimation<HTMLDivElement>();
  const { ref: listRef, isVisible: listVisible } = useScrollAnimation<HTMLDivElement>();

  // Filter parks
  const filteredParks = parks.filter((park) => {
    const matchRegion = selectedRegion === '全部地区' || park.region.includes(selectedRegion);
    const matchSearch = searchQuery === '' || 
      park.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      park.region.toLowerCase().includes(searchQuery.toLowerCase());
    const matchFacilities = selectedFacilities.length === 0 || 
      selectedFacilities.every((f) => park.facilities.includes(f));
    return matchRegion && matchSearch && matchFacilities;
  });

  const toggleFacility = (facility: string) => {
    setSelectedFacilities((prev) =>
      prev.includes(facility)
        ? prev.filter((f) => f !== facility)
        : [...prev, facility]
    );
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      <Navbar />
      
      {/* Page Header */}
      <div 
        ref={headerRef}
        className="pt-24 pb-12 bg-gradient-to-r from-[#0066CC] to-[#0052A3]"
      >
        <div className="container-custom">
          <div 
            className={`max-w-2xl transition-all duration-700 ${
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              OPC创业园区智能匹配
            </h1>
            <p className="text-lg text-white/80">
              精准推荐优质创业园区，享受租金减免、配套完善的创业环境
            </p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div 
        ref={filtersRef}
        className="sticky top-[60px] z-30 bg-white shadow-[0_2px_10px_rgba(0,0,0,0.06)]"
      >
        <div className="container-custom py-4">
          <div 
            className={`flex flex-col gap-4 transition-all duration-700 ${
              filtersVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            {/* Search and Main Filters */}
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#999999]" />
                <input
                  type="text"
                  placeholder="搜索园区名称或地区..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:border-[#0066CC] focus:outline-none focus:ring-2 focus:ring-[#0066CC]/10 transition-all duration-200"
                />
              </div>

              <div className="flex flex-wrap gap-3">
                <select
                  value={selectedRegion}
                  onChange={(e) => setSelectedRegion(e.target.value)}
                  className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:border-[#0066CC] focus:outline-none focus:ring-2 focus:ring-[#0066CC]/10 cursor-pointer transition-all duration-200"
                >
                  {regions.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>

                <select
                  value={selectedArea}
                  onChange={(e) => setSelectedArea(e.target.value)}
                  className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:border-[#0066CC] focus:outline-none focus:ring-2 focus:ring-[#0066CC]/10 cursor-pointer transition-all duration-200"
                >
                  {areas.map((a) => (
                    <option key={a} value={a}>{a}</option>
                  ))}
                </select>

                <select
                  value={selectedPeriod}
                  onChange={(e) => setSelectedPeriod(e.target.value)}
                  className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:border-[#0066CC] focus:outline-none focus:ring-2 focus:ring-[#0066CC]/10 cursor-pointer transition-all duration-200"
                >
                  {rentFreePeriods.map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Facilities Filter */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-[#666666] mr-2">配套设施:</span>
              {facilitiesList.map((facility) => (
                <button
                  key={facility}
                  onClick={() => toggleFacility(facility)}
                  className={`px-3 py-1.5 text-sm rounded-full transition-all duration-200 ${
                    selectedFacilities.includes(facility)
                      ? 'bg-[#0066CC] text-white'
                      : 'bg-gray-100 text-[#666666] hover:bg-gray-200'
                  }`}
                >
                  {facility}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Park List */}
      <div className="container-custom py-8">
        <div 
          ref={listRef}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredParks.length > 0 ? (
            filteredParks.map((park, index) => (
              <div
                key={park.id}
                className={`group bg-white rounded-xl overflow-hidden shadow-[0_2px_10px_rgba(0,0,0,0.04)] transition-all duration-500 hover:shadow-[0_20px_40px_rgba(0,102,204,0.15)] hover:-translate-y-2 ${
                  listVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                }`}
                style={{ transitionDelay: `${index * 80}ms` }}
              >
                {/* Image Placeholder */}
                <div className="h-40 bg-gradient-to-br from-[#0066CC]/10 to-[#FF9900]/10 flex items-center justify-center">
                  <Building2 className="w-16 h-16 text-[#0066CC]/30" />
                </div>

                <div className="p-6">
                  <h3 className="text-lg font-bold text-[#333333] mb-2 group-hover:text-[#0066CC] transition-colors duration-200">
                    <Link to={`/park/${park.id}`}>{park.name}</Link>
                  </h3>
                  
                  <div className="flex items-center gap-1 text-sm text-[#666666] mb-4">
                    <MapPin className="w-4 h-4 text-[#999999]" />
                    {park.region}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <Maximize className="w-4 h-4 text-[#0066CC]" />
                      <span className="text-[#666666]">{park.area}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="w-4 h-4 text-[#FF9900]" />
                      <span className="text-[#666666]">免租{park.rentFreePeriod}</span>
                    </div>
                  </div>

                  {/* Facilities */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {park.facilities.slice(0, 4).map((facility) => (
                      <span
                        key={facility}
                        className="px-2 py-1 bg-[#F0F7FF] text-[#0066CC] text-xs rounded-md"
                      >
                        {facility}
                      </span>
                    ))}
                    {park.facilities.length > 4 && (
                      <span className="px-2 py-1 bg-gray-100 text-[#666666] text-xs rounded-md">
                        +{park.facilities.length - 4}
                      </span>
                    )}
                  </div>

                  {/* Policy */}
                  <div className="flex items-start gap-2 p-3 bg-[#FFF5E6] rounded-lg mb-4">
                    <Home className="w-4 h-4 text-[#FF9900] flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-[#666666]">{park.preferentialPolicy}</span>
                  </div>

                  <Link
                    to={`/park/${park.id}`}
                    className="flex items-center justify-center w-full py-2.5 bg-[#0066CC] text-white rounded-lg hover:bg-[#0052A3] transition-colors duration-200 group/btn"
                  >
                    查看详情
                    <ChevronRight className="w-4 h-4 ml-1 transition-transform duration-200 group-hover/btn:translate-x-1" />
                  </Link>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full bg-white rounded-xl p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-8 h-8 text-[#999999]" />
              </div>
              <h3 className="text-lg font-medium text-[#333333] mb-2">未找到相关园区</h3>
              <p className="text-sm text-[#666666]">请尝试调整筛选条件或搜索关键词</p>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
