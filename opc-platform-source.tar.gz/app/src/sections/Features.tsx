import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { features } from '@/data';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function Features() {
  const { ref: titleRef, isVisible: titleVisible } = useScrollAnimation<HTMLDivElement>();
  const { ref: cardsRef, isVisible: cardsVisible } = useScrollAnimation<HTMLDivElement>();

  return (
    <section className="section-padding bg-[#F5F5F5] relative overflow-hidden">
      {/* Background Decorations */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-0 w-[200px] h-[200px] bg-[#0066CC]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-0 w-[300px] h-[300px] bg-[#FF9900]/5 rounded-full blur-3xl" />
      </div>

      <div className="container-custom relative z-10">
        {/* Section Header */}
        <div 
          ref={titleRef}
          className={`text-center max-w-2xl mx-auto mb-16 transition-all duration-700 ${
            titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-[#333333] mb-4">
            全方位<span className="text-[#0066CC]">创业服务</span>
          </h2>
          <p className="text-lg text-[#666666]">
            四大核心功能模块，覆盖创业全周期
          </p>
        </div>

        {/* Features Grid */}
        <div 
          ref={cardsRef}
          className="grid md:grid-cols-2 gap-6"
        >
          {features.map((feature, index) => (
            <Link
              key={feature.id}
              to={feature.link}
              className={`group relative bg-white rounded-2xl p-8 flex gap-6 shadow-[0_4px_15px_rgba(0,0,0,0.05)] transition-all duration-500 hover:shadow-[0_25px_50px_rgba(0,102,204,0.12)] overflow-hidden ${
                cardsVisible 
                  ? 'opacity-100 translate-x-0' 
                  : index % 2 === 0 
                    ? 'opacity-0 -translate-x-20' 
                    : 'opacity-0 translate-x-20'
              }`}
              style={{
                transitionDelay: `${200 + index * 150}ms`,
              }}
            >
              {/* Left Border Accent */}
              <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-[#0066CC] to-[#FF9900] transform scale-y-0 group-hover:scale-y-100 transition-transform duration-400 origin-top" />

              {/* Icon */}
              <div className="flex-shrink-0">
                <div className="w-20 h-20 bg-[#F0F7FF] rounded-xl flex items-center justify-center transition-all duration-400 group-hover:bg-gradient-to-br group-hover:from-[#0066CC] group-hover:to-[#0052A3] group-hover:scale-110 group-hover:rotate-3">
                  <img
                    src={feature.icon}
                    alt={feature.title}
                    className="w-10 h-10 object-contain transition-all duration-400 group-hover:brightness-0 group-hover:invert"
                  />
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 flex flex-col">
                <h3 className="text-xl font-bold text-[#333333] mb-2 group-hover:text-[#0066CC] transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="text-sm text-[#666666] leading-relaxed mb-4 flex-1">
                  {feature.description}
                </p>
                <div className="flex items-center text-[#0066CC] font-medium text-sm">
                  <span>进入模块</span>
                  <ArrowRight className="w-4 h-4 ml-2 transition-transform duration-300 group-hover:translate-x-2" />
                </div>
              </div>

              {/* Hover Background Effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#F0F7FF]/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400 pointer-events-none" />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
