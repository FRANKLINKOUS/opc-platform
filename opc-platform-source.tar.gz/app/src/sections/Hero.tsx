import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-[#F0F7FF] via-white to-[#F5F5F5]">
      {/* Background Decorations */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Gradient Orbs */}
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-[#0066CC]/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-[#FF9900]/5 rounded-full blur-3xl animate-float-delayed" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#0066CC]/3 rounded-full blur-3xl animate-float-delayed-2" />
        
        {/* Grid Pattern */}
        <div 
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `
              linear-gradient(#0066CC 1px, transparent 1px),
              linear-gradient(90deg, #0066CC 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      <div className="container-custom relative z-10 pt-24 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          {/* Content */}
          <div className="max-w-xl">
            {/* Badge */}
            <div 
              className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-[0_2px_10px_rgba(0,0,0,0.06)] mb-6 animate-fade-in"
              style={{ animationDelay: '200ms' }}
            >
              <Sparkles className="w-4 h-4 text-[#FF9900]" />
              <span className="text-sm font-medium text-[#666666]">AI驱动的创业服务平台</span>
            </div>

            {/* Title */}
            <h1 className="text-4xl sm:text-5xl lg:text-[56px] font-bold text-[#333333] leading-tight mb-6">
              <span 
                className="inline-block animate-slide-up"
                style={{ animationDelay: '300ms' }}
              >
                OPC
              </span>
              <br />
              <span 
                className="inline-block animate-slide-up"
                style={{ animationDelay: '450ms' }}
              >
                创业服务平台
              </span>
            </h1>

            {/* Subtitle */}
            <p 
              className="text-xl text-[#0066CC] font-semibold mb-4 animate-slide-up"
              style={{ animationDelay: '600ms' }}
            >
              连接OPC创业者与本地资源的智能枢纽
            </p>

            {/* Description */}
            <p 
              className="text-base text-[#666666] leading-relaxed mb-8 animate-slide-up"
              style={{ animationDelay: '750ms' }}
            >
              AI驱动的政策匹配、园区推荐、服务对接，让创业之路更高效、更智能。
              聚合全国20+城市创业资源，服务10000+创业者。
            </p>

            {/* CTA Buttons */}
            <div 
              className="flex flex-col sm:flex-row gap-4 animate-slide-up"
              style={{ animationDelay: '900ms' }}
            >
              <Link
                to="/park"
                className="btn-primary group"
              >
                立即匹配园区
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
              <Link
                to="/about"
                className="btn-secondary"
              >
                了解更多
              </Link>
            </div>

            {/* Stats Preview */}
            <div 
              className="flex flex-wrap gap-6 mt-10 pt-8 border-t border-gray-200 animate-fade-in"
              style={{ animationDelay: '1100ms' }}
            >
              <div>
                <div className="text-2xl font-bold text-[#0066CC]">20+</div>
                <div className="text-sm text-[#999999]">覆盖城市</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-[#0066CC]">500+</div>
                <div className="text-sm text-[#999999]">聚合政策</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-[#0066CC]">100+</div>
                <div className="text-sm text-[#999999]">对接园区</div>
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div 
            className="relative lg:pl-8 animate-scale-in"
            style={{ animationDelay: '600ms' }}
          >
            <div className="relative">
              {/* Image Container with 3D effect */}
              <div 
                className="relative rounded-2xl overflow-hidden shadow-[0_30px_60px_rgba(0,102,204,0.2)] transition-transform duration-500 hover:scale-[1.02]"
                style={{
                  perspective: '1000px',
                  transformStyle: 'preserve-3d',
                }}
              >
                <img
                  src="/hero-image.png"
                  alt="OPC创业服务平台"
                  className="w-full h-auto"
                  loading="eager"
                />
              </div>

              {/* Floating Cards */}
              <div 
                className="absolute -bottom-6 -left-6 bg-white rounded-xl p-4 shadow-[0_10px_30px_rgba(0,0,0,0.1)] animate-float"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#E6F2FF] rounded-lg flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-[#0066CC]" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-[#333333]">智能匹配</div>
                    <div className="text-xs text-[#999999]">准确率95%</div>
                  </div>
                </div>
              </div>

              <div 
                className="absolute -top-4 -right-4 bg-white rounded-xl p-4 shadow-[0_10px_30px_rgba(0,0,0,0.1)] animate-float-delayed"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#FFF5E6] rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-[#FF9900]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-[#333333]">已认证</div>
                    <div className="text-xs text-[#999999]">10000+创业者</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent pointer-events-none" />
    </section>
  );
}
