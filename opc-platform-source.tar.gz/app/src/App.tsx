import { Routes, Route } from 'react-router-dom';
import Home from '@/pages/Home';
import Policy from '@/pages/Policy';
import Park from '@/pages/Park';
import Service from '@/pages/Service';
import Case from '@/pages/Case';
import About from '@/pages/About';
import Contact from '@/pages/Contact';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/policy" element={<Policy />} />
      <Route path="/park" element={<Park />} />
      <Route path="/service" element={<Service />} />
      <Route path="/case" element={<Case />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
    </Routes>
  );
}

export default App;
